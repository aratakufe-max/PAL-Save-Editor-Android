#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
npm ci
npm run build
rm -rf android/app/src/main/assets
mkdir -p android/app/src/main/assets
cp -R dist/. android/app/src/main/assets/
cd android
./gradlew assembleDebug
