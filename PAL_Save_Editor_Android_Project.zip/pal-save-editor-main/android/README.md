# PAL Save Editor Android 版

這個 Android 專案以原 PAL Save Editor 網頁版為核心，加入 Android 原生檔案選取與儲存橋接：

- 匯入：Android `ACTION_OPEN_DOCUMENT`，不需要要求整個儲存空間權限。
- 匯出：Android `ACTION_CREATE_DOCUMENT`，由使用者選擇儲存位置。
- 編輯核心仍由原本的網頁程式處理，存檔資料不需上傳伺服器。

## 建置

1. 先在專案根目錄執行 `npm ci`。
2. 執行 `npm run build`，產生 `dist/`。
3. 將 `dist/` 的內容複製到 `android/app/src/main/assets/`。
4. 用 Android Studio 開啟 `android/`。
5. `Build > Build APK(s)`。

也可以在 `android/` 使用：

```bash
./gradlew assembleDebug
```

APK 會位於 `android/app/build/outputs/apk/debug/app-debug.apk`。
